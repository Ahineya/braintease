struct IStream;
