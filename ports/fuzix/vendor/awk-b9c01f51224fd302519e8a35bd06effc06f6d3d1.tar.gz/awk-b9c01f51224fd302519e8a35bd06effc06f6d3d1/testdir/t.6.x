{print NF,$0}
