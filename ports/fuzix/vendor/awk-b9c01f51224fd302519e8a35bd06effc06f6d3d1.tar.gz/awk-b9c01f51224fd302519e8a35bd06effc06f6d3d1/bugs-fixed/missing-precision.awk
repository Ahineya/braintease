BEGIN { printf("%*s"); }
